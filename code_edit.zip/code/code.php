<?php

/**
 * Перед вами контроллер, который обрабатывает следующие запросы:
 *  - Загрузка страницы со списком сотрудников
 *  - Выгрузка отчета по сотрудникам в файл и скачивание
 *  - Загрузка страницы создания сотрудника с функционалом создания
 * 
 * DataProvider - это простые интерфейсы для доступа к БД. 
 * Кроме получения и сохранения данных в БД в них нет ничего (дополнительной логики, проверок и тд)
 * 
 * Employees\DataProvider::getEmployees возвращает объекты сотрудников с полями
 *  - id
 *  - name
 *  - phone
 *  - email
 *  - category_id
 * 
 * Employees\DataProvider::getCategories возвращает объекты категорий с полями
 *  - id
 *  - name
 * 
 * Tasks\DataProvider::getEmployeeTasks возвращает объекты задач сотрудника с полями
 *  - id
 *  - name
 *  - worktime
 * 
 * Задание
 * Проведите тщательное код-ревью
 *  - Исправьте ошибки, если есть
 *  - Доработайте код, если он требует доработки на ваш взгляд
 *  - Измените организацию кода в соответствии с известными вам принципами разработки
 */

use Employees\DataProvider as EmployeesProvider;
use Tasks\DataProvider as TasksProvider;

class EmployeeController
{
    private $employeesProvider;
    private $tasksProvider;
    public function __construct() //Написан метод, дабы облегчить повторяющийся код создания EmployeesProvider и TasksProvider
    {
        $this->employeesProvider = new EmployeesProvider('hostname', '3030', 'user', 'password');
        $this->tasksProvider = new TasksProvider('hostname', '3040', 'user', 'password');
    }

    public function actionList()
    {
        if (isset($_GET['limit'], $_GET['offset'], $_GET['sort'])){ //Подлючена минимальная проверка на гет-запросов (Хотя бы их наличия и отсутствия значения NULL)
            $employees = $this -> EmployeesProvider ->getEmployees($_GET['limit'], $_GET['offset'], $_GET['sort']); // Вместо items информацию о сотрудниках теперь хранит employees. 2 строки были соединины в одну с помощью метода __construct

            $result = [];
            foreach ($employees as $employee) { // Также изменены параметры цикла, ведь items заменены на employees
                $categories = $this -> EmployeesProvider -> getCategories(); // Заменено на создание с помощью метода __construct(), т.к. employees теперь хранит информацию о сотрудниках
                $tasks = $this -> TasksProvider -> getEmployeeTasks($employee->id); // Заменено на заполнение с помощью __construct(). 2 строки объеденины в одну (Также изменен параметр метода на employee)
                $worktime = 0;
                foreach ($tasks as $task) {
                    $worktime += $task->worktime;
                }
                $result[] = [
                    $employee->name, // item изменен на employee
                    $employee->phone, // item изменен на employee
                    $employee->email, // item изменен на employee
                    $categories[$employee->category_id]->name, // item изменен на employee
                    $worktime
                ];
            }

            return $this->view('list', $result);
        }
    }

    public function actionDownloadReport()
    {
        if (isset($_GET['sort'])){ //Подлючена минимальная проверка на гет-запроса (Хотя бы их наличия и отсутствия значения NULL)
            $employees = $this -> EmployeesProvider ->getEmployees(null, null, $_GET['sort']); // Вместо items информацию о сотрудниках теперь хранит employees. 2 строки были соединины в одну с помощью метода __construct

            $fileHandle = fopen('php://memory', 'w'); //название $f изменено (Меня всю жизнь учили писать переменные полностью)
            foreach ($employees as $employee) { // Также изменены параметры цикла, ведь items заменены на employees
                $categories = $this -> EmployeesProvider -> getCategories(); // Заменено на создание с помощью метода __construct(), т.к. employees теперь хранит информацию о сотрудниках
                $tasks = $this -> TasksProvider -> getEmployeeTasks($employee->id); // Заменено на заполнение с помощью __construct(). 2 строки объеденины в одну (Также изменен параметр метода на employee)
                $worktime = 0;
                foreach ($tasks as $task) {
                    $worktime += $task->worktime;
                }
                fputcsv($fileHandle, [ // f изменен на fileHandle
                    $employee->name, // item изменен на employee
                    $employee->phone, // item изменен на employee
                    $employee->email, // item изменен на employee
                    $categories[$employee->category_id]->name, // item изменен на employee
                    $worktime
                ], ';');
            }

            fseek($fileHandle, 0); // f изменен на fileHandle
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="report.csv";');
            fpassthru($fileHandle);
        }
    }

    public function actionCreateEmployee()
    {
        if(isset($_POST['name'], $_POST['phone'], $_POST['email'], $_POST['category'])){ //Подлючена минимальная проверка на пост-запросов (Хотя бы их наличия и отсутствия значения NULL)
            $provider = $this -> EmployeesProvider -> create($_POST['name'], $_POST['phone'], $_POST['email'], $_POST['category']); //// Заменено на заполнение с помощью __construct(). 2 строки объеденины в одну (Также изменен параметр метода на employee)
            return $this->view($provider); // Строка "create" заменена на переменную provider
        }
        else{
            return $this->view('Заполните все поля');
        }
    }
}
